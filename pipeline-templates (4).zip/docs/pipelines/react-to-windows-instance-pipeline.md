# `react-to-windows-instance-pipeline.yml`

Builds a React app (Vite or Create React App), runs tests and SAST, and deploys
the static build to IIS on a Windows VM per environment.

It is the React counterpart of
[`angular-to-windows-instance-pipeline.yml`](angular-to-windows-instance-pipeline.md):
same stage flow, same branch → environment convention, same IIS deploy,
health check and auto-rollback. Only the build is React-specific.

See [../../README.md](../../README.md) for the shared architecture, the
branch → environment convention, and prerequisites common to all pipelines.

## Stage flow

```
Build_And_Security                (install, test + coverage, build, web.config, publish artifact)
  → Deploy_<env>                    (IIS over SSH: backup → deploy → health check → auto-rollback)
      → DAST_dev + QA_Test            (hotfix branches only, once, after the dev deploy)
  → DAST_<branch env> + QA_Test     (non-hotfix branches only)
  → Rollback_IIS                    (only if DAST or QA failed)
  → Deploy_dr                       (production branch only)
```

## What is different from the Angular pipeline

| | Angular | React |
|---|---|---|
| Tests | Karma, `--browsers=ChromeHeadless` | Jest by default; Vitest via `testCommand` |
| Coverage file | `coverage/cobertura/cobertura-coverage.xml` | `coverage/cobertura-coverage.xml` |
| Build output | `dist` | `dist` (Vite) or `build` (CRA) |
| IIS `web.config` | not generated | SPA fallback generated into the build output |
| `deployPath` | has a default | **required** |
| `backupRoot` on deploy | not passed (deploy uses `C:\Applications\Backups`, rollback uses `D:\…`) | passed to both deploy and rollback |

## Prerequisites

Everything the Angular pipeline needs, plus:

- **IIS URL Rewrite module** installed on every target VM (dev, uat, pilot,
  production, dr). The generated `web.config` uses a `<rewrite>` section; without
  the module IIS returns HTTP 500.19, the post-deploy health check fails, and the
  deploy auto-rolls back. Install once per server:
  `winget install Microsoft.IISUrlRewrite` or the MSI from iis.net.
- `deploy-iis.ps1` installed at `C:\Deploy\bin\deploy-iis.ps1` on the VM (same as
  every IIS-over-SSH pipeline). No changes to the script are needed for React.
- SSH service connection `win_rv-<TeamProject>`, `ARM-ServiceConnection`,
  ADO Environments `dev` / `uat` / `pilot` / `production` / `dr`, and the
  BrowserStack variable group for the QA stage.

### `package.json` scripts the pipeline expects

The default `environmentConfig` calls one build script per environment and one
test script:

```json
{
  "scripts": {
    "build-dev":   "vite build --mode dev",
    "build-uat":   "vite build --mode uat",
    "build-pilot": "vite build --mode pilot",
    "build-prod":  "vite build --mode production",
    "test":        "vitest"
  }
}
```

For Create React App use `react-scripts build` in each build script, set
`buildOutputPath: 'build'`, and keep the default Jest `testCommand`.

### Coverage

`failIfCoverageEmpty` is `true` by default, so the test run must write a
cobertura report:

- **Jest / CRA**: the default `testCommand` already passes
  `--coverageReporters=cobertura`.
- **Vitest**: add `@vitest/coverage-v8` as a dev dependency and set
  `testCommand: 'npx vitest run --coverage --coverage.reporter=cobertura --coverage.reporter=text'`.

If the app has no tests yet, set `failIfCoverageEmpty: false`.

### Environment variables

React inlines env vars **at build time**, so they must exist before
`npm run build`. With `useKeyVault: true`, Key Vault secrets named
`<projectName>_<VAR>` are written to `.env` as `<VAR>=value` just before the
build step. The variable name must keep the prefix your tooling exposes to the
browser:

| Key Vault secret | Ends up in `.env` as | Tooling |
|---|---|---|
| `my-react-app_VITE_API_URL` | `VITE_API_URL=…` | Vite (`import.meta.env.VITE_API_URL`) |
| `my-react-app_REACT_APP_API_URL` | `REACT_APP_API_URL=…` | CRA (`process.env.REACT_APP_API_URL`) |

Anything in `.env` ends up in the public JS bundle. Never put a real secret
(API keys with write access, client secrets) there.

## Parameters

| Name | Type | Required | Default | Notes |
|---|---|---|---|---|
| `projectName` | string | **yes** | — | Lowercase alphanumeric and hyphens. Also the IIS site and app pool name. |
| `deployPath` | string | **yes** | — | Folder on the Windows VM the site is served from. |
| `qualysWebAppName` | string | **yes** | — | Qualys WAS application name for DAST. |
| `port` | number | **yes** | — | Port the IIS site binds to. |
| `environmentConfig` | object | no | dev/uat/pilot/production/dr | Per-environment `buildCommand`, `poolName`, and optional `sshEndpoint` / `protocol` / `certificateName` / `hostHeader`. |
| `useKeyVault` | boolean | no | `false` | Write build-time env vars to `.env` from Key Vault. |
| `buildCommand` | string | no | `''` (→ `environmentConfig[<env>].buildCommand`) | Explicit override wins over the per-environment default. |
| `buildOutputPath` | string | no | `'dist'` | `'build'` for Create React App. |
| `testCommand` | string | no | Jest with cobertura coverage | Runs with `CI=true`. See [Coverage](#coverage) for Vitest. |
| `coverageSummaryFile` | string | no | `'coverage/cobertura-coverage.xml'` | Relative to repo root. |
| `failIfCoverageEmpty` | boolean | no | `true` | Set `false` for apps without tests yet. |
| `generateSpaWebConfig` | boolean | no | `true` | Writes an SPA-fallback `web.config` into the build output. Skipped if the app already ships one (e.g. `public/web.config`). |
| `BuildType` | string | no | `'none'` | Passed through to the SAST step. |
| `poolName` | string | no | `''` | Build pool. Empty = Microsoft-hosted `ubuntu-latest`. |
| `customSubFolderForArtifact` | string | no | `''` | Rarely needed for React; builds are flat. |
| `customDestinationFolder` | string | no | `''` | Paired with the above. |
| `backupRoot` | string | no | `'D:\Applications\Backups'` | Used by both deploy and rollback. |
| `rollbackToBuildId` | string | no | `''` | Empty = latest backup in the manifest. |
| `healthCheckPath` | string | no | `'/'` | Probed on `localhost:<port>` after deploy. |
| `qaRepoName` | string | no | `Plain_QA_Automation_Repo` | BrowserStack QA automation repo. |
| `qaAzureProject` | string | no | `QA_Automation_Repo` | ADO project containing the QA repo. |

## The generated `web.config`

```xml
<rule name="SPA fallback" stopProcessing="true">
  <match url=".*" />
  <conditions logicalGrouping="MatchAll">
    <add input="{REQUEST_FILENAME}" matchType="IsFile" negate="true" />
    <add input="{REQUEST_FILENAME}" matchType="IsDirectory" negate="true" />
  </conditions>
  <action type="Rewrite" url="index.html" />
</rule>
```

Real files (JS, CSS, images) are served as-is; every other path returns
`index.html` so React Router can resolve it. `index.html` is sent with
`Cache-Control: no-cache` so users pick up a new release immediately, while
the hashed bundles stay cacheable. A `.webmanifest` MIME type is also registered.

To customise (proxy `/api` to a backend, add security headers, etc.), commit
your own `public/web.config`. Vite and CRA both copy `public/` into the build
output, and the pipeline leaves an existing `web.config` alone.

## Minimal example

```yaml
resources:
  repositories:
    - repository: templates
      type: git
      name: <your-project>/pipeline-templateS
      ref: main

extends:
  template: pipelines/react-to-windows-instance-pipeline.yml@templates
  parameters:
    projectName: my-react-app
    deployPath: 'D:\Applications\my-react-app'
    port: 8090
    qualysWebAppName: 'my-react-app (DevSecOps)'
```

Create React App + no tests yet:

```yaml
extends:
  template: pipelines/react-to-windows-instance-pipeline.yml@templates
  parameters:
    projectName: my-cra-app
    deployPath: 'D:\Applications\my-cra-app'
    port: 8091
    qualysWebAppName: 'my-cra-app (DevSecOps)'
    buildOutputPath: 'build'
    failIfCoverageEmpty: false
```

## Known limitations for this pipeline

These are inherited from the shared templates and apply equally to the Angular
pipeline:

- **Hotfix runs stop at `pilot`.** The hotfix loop is `dev,uat,pilot`;
  production is commented out until it is signed off, same as Angular.
- **Hotfix `uat` waits on `Rollback_IIS`**, which only runs when DAST/QA fail,
  so on the happy path the hotfix chain does not advance past `dev`. See the
  note at the top of `templates/stages/deploy-to-instance-stage.yml`.
- **The rollback stage runs in agent mode** (`resourceType: virtualMachine`,
  local PowerShell), while deploys default to SSH mode. On an SSH-only VM with
  no agent registered, `Rollback_IIS` has nowhere to run. Auto-rollback inside
  the deploy step (on a failed health check) still works.
- **The `ROLLBACK_PERFORMED` output path** in the rollback condition
  (`Build_Frontend.healthGate…`) doesn't match the deploy job. In practice it
  is harmless: a deploy that auto-rolled back exits 1, so
  `Deploy_<env>.result` is not `Succeeded` and the rollback stage is skipped anyway.
 